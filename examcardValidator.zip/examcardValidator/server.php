<?php   session_start();


$server = mysqli_connect("localhost", "root", "", "qrvalidator") or die("Failed to connect");
// if($server){
//     echo "connected";
// }else{
//     echo "not Connected";
// }

?>